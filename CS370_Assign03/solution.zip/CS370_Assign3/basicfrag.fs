/* Default fragment shader */

void main()
{
    gl_FragColor = gl_Color;
}